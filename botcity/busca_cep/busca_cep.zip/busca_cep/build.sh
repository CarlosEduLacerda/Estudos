#!/bin/bash

python setup.py sdist
